# Opdrachten voor Mobile & Internet 1, les 6 

Deze les gaat over het eerte hoofdstuk van CSS: 

- [CSS Syntax](https://rogiervdl.github.io/CSS-course/01_syntax.html#/)

Begin bij **les06 opgave.pdf**
# Opdrachten voor Mobile & Internet 1, les 5 

Deze les gaat over alle geziene hoofdstukken, plus dit hoofdstuk: 

- [Sections](https://rogiervdl.github.io/HTML-course/09_sections.html#/)

Je leert nu elementen groeperen in sections (`<div>`, `<span>`, `<main>`, `<section>`, `<article>`, `<aside>` en `<nav>`). Tevens bestaat deze oefening ook uit meerdere pagina's, zodat je ze leert linken tot één site. 

Begin bij **les05 opgave.pdf**